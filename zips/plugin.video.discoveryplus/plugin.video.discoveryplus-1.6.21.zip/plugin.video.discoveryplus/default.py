# -*- coding: utf-8 -*-
from resources.lib import addon

if __name__ == '__main__':
    addon.run()